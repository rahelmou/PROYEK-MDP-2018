package stts.edu.burgermenu;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {

    private ListView lv ;
    private ArrayAdapter<String> listAdapter ;
    private ArrayList<String> menu;
    @Override
    public void onCreate(Bundle saveInstanceState)
    {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_main);

        ListView menuList=(ListView)findViewById(R.id.listMenu);

        menu = new ArrayList<String>();
        getMenu();

        ArrayAdapter<String> arrayAdapter =
                new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, menu);

        menuList.setAdapter(arrayAdapter);

        menuList.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            public void onItemClick(AdapterView<?> arg0, View v, int position, long arg3)
            {
                String selectedMenu=menu.get(position);
                if(selectedMenu=="Notification") {
                    Intent iMenu = new Intent(getApplicationContext(), notification.class);
                    startActivity(iMenu);
                }
                else if(selectedMenu=="Message")
                {
                    Intent iMenu = new Intent(getApplicationContext(), message.class);
                    startActivity(iMenu);
                }
                else if(selectedMenu=="Profile")
                {
                    Intent iMenu = new Intent(getApplicationContext(), editProfil.class);
                    startActivity(iMenu);
                }
                else if(selectedMenu=="Post")
                {
                    Intent iMenu = new Intent(getApplicationContext(), post.class);
                    startActivity(iMenu);
                }
                else if(selectedMenu=="Logout")
                {
                    Intent iMenu = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(iMenu);
                }
            }
        });
    }

    void getMenu()
    {
        menu.add("Notification");
        menu.add("Message");
        menu.add("Profile");
        menu.add("Post");
        menu.add("Logout");
    }

}
